﻿using Microsoft.AspNetCore.Mvc;
using StudentWebApp.Models;
using System.Diagnostics;
using System.Collections.Generic;
namespace StudentWebApp.Controllers
{
   
    public class HomeController : Controller

    {
        private readonly ILogger<HomeController> _logger;

        public HomeController(ILogger<HomeController> logger)
        {
            _logger = logger;
        }

        public IActionResult Index()
        {
            return View();
          
        }

        public IActionResult Privacy()
        {
            return View("Welcome to IACSD...");
        }

        [HttpGet]
        public IActionResult Login()
        {

            Console.WriteLine("Http Get Request");
            return View();
        }

        [HttpPost]
        public IActionResult Login(string email,string password)
        {

            Console.WriteLine("In Login Page");
            if (email=="ss@gmail.com" && password=="ss8007") {
            
            return RedirectToAction("Welcome");
                    
            }

            return View();
        }


        
        public IActionResult Welcome()
        {

            Console.WriteLine("Welcome to ASP .NET");
            return View();
        }

        [HttpGet]
        public IActionResult Register() {
            Console.WriteLine("In get Register method");
            return View();        
        }
        [HttpPost]
        public IActionResult Register(string fname,string lname,string city,string email,string password,string phone)
        {
            Student stud = new Student();
           
            stud.fname = fname;
            stud.lname = lname;
            stud.city = city;
            stud.email = email;
            stud.password = password;
            stud.phone = phone;
            Console.WriteLine("In register method");
            
            return RedirectToAction("List");
            
            return View();
        }
        
        public IActionResult List()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}