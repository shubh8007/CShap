﻿using System.Runtime.Versioning;

namespace StudentWebApp.Models
{
    public class Student
    {
        //poco Class-plane old clr object.
       
        public string fname { get; set; }
        public string lname { get; set; }
        public string city { get; set; }    
        public string email { get; set; }
        public string password { get; set; } 
        
        public string phone { get; set; }


        public override string ToString()
        {
            return string.Format("{0},{1},{2},{3},{4}",fname,lname,city,email,password,phone);
        }

    }
}
